# Rudro Roy Portfolio (React + TypeScript + Vite)
Run: `npm install` then `npm run dev` (preview) or `npm run build` (output in dist/).
## Edit these files
- src/data/site.ts: email, WhatsApp (digits with country code), LinkedIn, Facebook, optional form endpoint, availability label
- src/data/projects.ts: real projects (add images to public/images/projects/, remove `placeholder: true`)
- src/data/tools.ts: keep only tools you really use; services.ts: service cards
- public/images/rudro-portrait.jpg (hero) and rudro-event.jpg (About)
## Still missing
Contact details, real project images and descriptions, confirmed tool list, a form service (or email) to receive messages, and a portrait without the HONOR/Harcourt watermark (the hero crops it out).
