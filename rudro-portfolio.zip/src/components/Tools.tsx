import { tools } from '../data/tools'
export default function Tools() {
  return (
    <section className="sec alt">
      <div className="wrap">
        <div data-reveal><h2>My Creative &amp; Marketing Toolkit.</h2></div>
        <div className="tools" data-reveal>
          {tools.map(g => <div key={g.group}><h3>{g.group}</h3><ul className="chips">{g.items.map(t => <li key={t}>{t}</li>)}</ul></div>)}
        </div>
      </div>
    </section>
  )
}
