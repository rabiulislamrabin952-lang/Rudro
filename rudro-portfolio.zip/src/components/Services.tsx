import { services } from '../data/services'
export default function Services() {
  return (
    <section id="services" className="sec">
      <div className="wrap">
        <div data-reveal><p className="label">WHAT I DO</p><h2>Services Built Around Your Growth.</h2></div>
        <ul className="grid3">
          {services.map((s, i) => (
            <li key={s.title} className="card svc" data-reveal>
              <span className="bar" aria-hidden="true" /><span className="num">{String(i + 1).padStart(2, '0')}</span>
              <h3>{s.title}</h3><p>{s.text}</p>
            </li>))}
        </ul>
      </div>
    </section>
  )
}
