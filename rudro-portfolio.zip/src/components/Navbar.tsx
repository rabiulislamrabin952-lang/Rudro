import { useState } from 'react'
import { site } from '../data/site'
const links = ['Home', 'About', 'Services', 'Portfolio', 'Contact']
export default function Navbar() {
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)
  return (
    <header className="nav">
      <div className="wrap nav-in">
        <a className="logo" href="#home" onClick={close}>{site.name.toUpperCase()}</a>
        <nav id="menu" className={open ? 'open' : ''} aria-label="Main">
          {links.map(l => <a key={l} href={`#${l.toLowerCase()}`} onClick={close}>{l}</a>)}
        </nav>
        <a className="btn btn-sm cta-nav" href="#contact">Let's Talk</a>
        <button className="burger" aria-expanded={open} aria-controls="menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen(!open)}><span /><span /></button>
      </div>
    </header>
  )
}
