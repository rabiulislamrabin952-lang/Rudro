import { site } from '../data/site'
export default function Footer() {
  const l = ['Home', 'About', 'Services', 'Portfolio', 'Contact']
  const s = site.contact
  return (
    <footer className="foot"><div className="wrap">
      <div><strong className="logo">{site.name.toUpperCase()}</strong><p>{site.title}</p></div>
      <nav aria-label="Footer">{l.map(x => <a key={x} href={`#${x.toLowerCase()}`}>{x}</a>)}</nav>
      <nav aria-label="Social">{s.linkedin ? <a href={s.linkedin} target="_blank" rel="noreferrer">LinkedIn</a> : <span>LinkedIn</span>}{s.facebook ? <a href={s.facebook} target="_blank" rel="noreferrer">Facebook</a> : <span>Facebook</span>}</nav>
      <p className="copy">© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
    </div></footer>
  )
}
