import { site } from '../data/site'
export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="glow" aria-hidden="true" />
      <div className="wrap hero-grid">
        <div className="hero-copy">
          <p className="label a1">DIGITAL MARKETING × AI</p>
          <h1 className="a2">Turning Digital<br />Ideas <span className="acc">Into Growth.</span></h1>
          <p className="lead a3">I'm Rudro Roy, a Digital Marketer &amp; AI Expert helping businesses strengthen their digital presence through strategic marketing, creative content, and AI-powered solutions.</p>
          <div className="row a4">
            <a className="btn" href="#contact">Work With Me</a>
            <a className="btn btn-ghost" href="#portfolio">Explore My Work</a>
          </div>
          {site.available && <p className="avail a4"><i aria-hidden="true" />{site.available}</p>}
        </div>
        <figure className="portrait a5">
          <img src="/images/rudro-portrait.jpg" width={1200} height={1500} alt="Rudro Roy in a burgundy blazer and white shirt, standing on a rooftop with the city behind him" fetchPriority="high" />
        </figure>
      </div>
    </section>
  )
}
