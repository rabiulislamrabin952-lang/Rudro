import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Services from './components/Services'
import Portfolio from './components/Portfolio'
import Process from './components/Process'
import Tools from './components/Tools'
import Contact from './components/Contact'
import Footer from './components/Footer'
import { useReveal } from './components/useReveal'

export default function App() {
  useReveal()
  return (<>
    <a className="skip" href="#main">Skip to content</a>
    <Navbar />
    <main id="main"><Hero /><About /><Services /><Portfolio /><Process /><Tools /><Contact /></main>
    <Footer />
  </>)
}
