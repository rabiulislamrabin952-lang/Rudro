// EDIT ME: keep only tools you actually use, and add any missing ones.
export const tools: { group: string; items: string[] }[] = [
  { group: 'Marketing', items: ['Google Search Console', 'Google Analytics', 'Google Ads', 'Meta Ads Manager'] },
  { group: 'Creative', items: ['Canva', 'Adobe Photoshop', 'Adobe Illustrator', 'Adobe Premiere Pro'] },
  { group: 'AI', items: ['ChatGPT', 'Add the other AI tools you use'] },
]
