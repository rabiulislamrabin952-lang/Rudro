export interface Service { title: string; text: string }
export const services: Service[] = [
  { title: 'SEO & Lead Generation', text: 'Help businesses improve online visibility and attract relevant potential customers.' },
  { title: 'Social Media Marketing', text: 'Develop structured social media strategies and content plans aligned with business goals.' },
  { title: 'Social Media Design', text: 'Create professional social media graphics and brand-consistent visual content.' },
  { title: 'AI Content Creation', text: 'Use AI tools to support content ideation, production, and creative workflows.' },
  { title: 'Content Strategy', text: 'Plan useful, audience-focused content that supports brand awareness and business growth.' },
  { title: 'Personal Branding', text: 'Help professionals communicate their expertise and build a consistent online identity.' },
]
